enum
{
	_FIRST_ELEMENT_ = 10000,
	_DUMMY_ELEMENT_
};
