#ifndef _Ogreeble_H_
#define _Ogreeble_H_
enum

{

	PG_SEED      = 10001,
	PG_SCALE     = 10002,
	PG_EXTRUDE   = 10003,

};

#endif